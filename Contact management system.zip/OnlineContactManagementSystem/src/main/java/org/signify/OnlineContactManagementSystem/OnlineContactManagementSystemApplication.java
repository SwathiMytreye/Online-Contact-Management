package org.signify.OnlineContactManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineContactManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineContactManagementSystemApplication.class, args);
	}

}
